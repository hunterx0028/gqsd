# 44利關人報表查詢API

> **重要提醒：本文件為API規格文件撰寫範本**
> 
> **個資遮罩原則：**
> - 身分證號：保留開頭1碼和結尾3碼，中間以***** 遮罩（如：A123*****789）
> - 姓名：中文姓名以***** 表示，英文姓名保留首字母和部分字母，中間以***** 遮罩
> - 地址：保留縣市和區域，詳細地址以**** 遮罩
> - 電話：保留區碼和部分號碼，核心號碼以***** 遮罩（如：02-1*****5678）
> - Email：保留網域部分，帳號部分以***** 遮罩（如：test@ex*****le.com）
> - 帳號：核心數字以*****遮罩

---

## 版本資訊
| 版號 | 日期 | 異動摘要 | 修訂人員 |
| --- | --- | --- | --- |
| 1.0 | 2026/11/06 | 初版 | 李桂昇 |
| 1.1 | 2026/11/06 | 依更新後分析文件調整狀態3、4的有效日期查詢條件 | 李桂昇 |

## PaaS Domain
| PaaS Domain | 說明 |
| --- | --- |
| http://com-oca-query-rs.apps.paas-sit.ocpt.cathaysec.com.tw | 測試環境，沒走Kong |
| https://api-sit-nh.intra-sit.cathaysec.com.tw/com-oca-query-rs | 系統整合測試環境 |
| https://api-uat-nh.intra-uat.cathaysec.com.tw/com-oca-query-rs | 使用者驗收測試環境 |
| https://api-nh.intra-prd.cathaysec.com.tw/com-oca-query-rs | 正式環境 |

## Swagger 參考文件
參考： http://com-oca-query-rs.apps.paas-sit.ocpt.cathaysec.com.tw/swagger/index.html

---

## API名稱：44利關人報表查詢

**API路徑：**[Paas Domain](#paas-domain)/StakeHolder/GetStakeHolderList

### 說明
本功能提供44利關人資料查詢服務。外部系統透過 API 發送查詢請求，系統接收 Request 後，依據「利關人ID」、「Type」、「狀態」及選填的「有效日期（起／迄）」（狀態為「全部含失效」、「全部有效」時，以 StartDATE 判斷是否落在區間內；「全部有效」另需 EndDATE 為空或未過期）查詢 StakeHolder 資料，並以 StakeHolder.COMID 關聯 LAW44PartyList.COMPANY_ID 取得公司名稱，將結果依 Response 封裝為 JSON 格式回傳予呼叫端。

### 輸入參數 (Header)
| 名稱 | 格式 | 說明 | 屬性 | 範例 | 備註 |
| --- | --- | --- | --- | --- | --- |
| **Token** | string | 連線驗證 | Req. |  |  |
| **UserId** | string | 使用者 | Req. |  |  |
| **SourceChannel** | string | 來源通道 | Req. |  | 追蹤用 |
| **MessageID** | string | 訊息代碼 | Req. | XXX-00000001 | 自編(交易日需唯一) |

### Body
| 名稱 | 格式 | 說明 | 屬性 | 範例 | 備註 |
| --- | --- | --- | --- | --- | --- |
| **EmployeeId** | string | 利關人ID | Req. | A123*****789 | 最長18碼，僅限英數字 |
| **Type** | string | Type | Req. | 44 | 目前僅「44」 |
| **Status** | string | 狀態 | Req. | 4 | 1:前一日新增 2:前一日刪除 3:全部含失效 4:全部有效 |
| StartDate | string | 有效日期（起） | Opt. | 2026/01/01 | yyyy/MM/dd；Status為1、2時忽略 |
| EndDate | string | 有效日期（迄） | Opt. | 2026/12/31 | yyyy/MM/dd；Status為1、2時忽略 |

### 輸出參數 Response
| 名稱 | 格式 | 說明 | 範例 | 備註 |
| --- | --- | --- | --- | --- |
| MsgId | string | TraceId | bd76582f1c9133693db8549553c69383 |  |
| Code | string | 執行結果代碼 | 000000 | 非000000為異常回覆 |
| Msg | string | 執行結果說明 | 處理成功 |  |
| Timestamp | string | 主機時戳 | 20260311104730561 | yyyyMMddHHmmssSSS |
| TimeElapsed | string | 主機耗時 | 5 | milliseconds |
| Data | Array | 第一層JSON Array[0..N] |  | 查無資料時為空陣列 |

### Data 欄位
| 名稱 | 格式 | 說明 | 範例 | 備註 |
| --- | --- | --- | --- | --- |
| EmployeeId | string | 利關人ID | A123*****789 | StakeHolder.EmployeeID |
| Name | string | 利關人名稱 | 王O明 | StakeHolder.NAME |
| ComId | string | 公司ID | 12****** | StakeHolder.COMID |
| CompanyName | string | 公司名稱 | 國泰O公司 | LAW44PartyList.COMPANY_NM |
| Type | string | Type | 44 | StakeHolder.Type |
| StartDate | string | 有效日期（起） | 2026/01/01 | yyyy/MM/dd |
| EndDate | string | 有效日期（迄） | 2026/12/31 | yyyy/MM/dd |

---
### 範例 JSON (Request)
```json
{
  "Header": {
    "Token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "UserId": "USER001",
    "SourceChannel": "WEB",
    "MessageID": "XXX-00000001"
  },
  "Body": {
    "EmployeeId": "A123*****789",
    "Type": "44",
    "Status": "4",
    "StartDate": "",
    "EndDate": ""
  }
}
```

### 範例 JSON (Response - 成功)
```json
{
  "MsgId": "bd76582f1c9133693db8549553c69383",
  "Code": "000000",
  "Msg": "處理成功",
  "Timestamp": "20260311104730561",
  "TimeElapsed": "5",
  "Data": [
    {
      "EmployeeId": "A123*****789",
      "Name": "王O明",
      "ComId": "12******",
      "CompanyName": "國泰O公司",
      "Type": "44",
      "StartDate": "2026/01/01",
      "EndDate": "2026/12/31"
    }
  ]
}
```

### 範例 JSON (Response - 失敗)
```json
{
  "MsgId": "bd76582f1c9133693db8549553c69383",
  "Code": "999999",
  "Msg": "系統錯誤：資料庫連線失敗",
  "Timestamp": "20260311104730561",
  "TimeElapsed": "5",
  "Data": null
}
```
---
### 邏輯
```sql
--輸入參數
DECLARE @EmployeeId AS VARCHAR(18)= 'A123*****789';
DECLARE @Type AS VARCHAR(2)= '44';
DECLARE @Status AS CHAR(1)= '4';   --1:前一日新增 2:前一日刪除 3:全部含失效 4:全部有效
DECLARE @StartDate AS DATE= NULL;
DECLARE @EndDate AS DATE= NULL;
DECLARE @Today AS DATE= CONVERT(DATE, GETDATE());

SELECT S.EmployeeID, S.NAME, S.COMID, P.COMPANY_NM, S.Type, S.StartDATE, S.EndDATE
FROM [dbo].[StakeHolder] S
LEFT JOIN [dbo].[LAW44PartyList] P ON S.COMID = P.COMPANY_ID
WHERE S.EmployeeID = @EmployeeId AND S.Type = @Type
  AND (   (@Status = '1' AND CONVERT(DATE, S.StartDATE) = DATEADD(DAY, -1, @Today))
       OR (@Status = '2' AND CONVERT(DATE, S.EndDATE) = DATEADD(DAY, -1, @Today))
       OR (@Status IN ('3','4')
           --有效日期(起迄)有輸入時，以StartDATE判斷是否落在區間內
           AND (@StartDate IS NULL OR CONVERT(DATE, S.StartDATE) >= @StartDate)
           AND (@EndDate IS NULL OR CONVERT(DATE, S.StartDATE) <= @EndDate)
           --全部有效：另需EndDATE為空或未過期
           AND (@Status = '3' OR S.EndDATE IS NULL OR CONVERT(DATE, S.EndDATE) >= @Today)))
ORDER BY S.StartDATE;
```

---

## 錯誤代碼說明
| 代碼 | 說明 | 處理方式 |
|------|--------|----------|
| 000000 | 處理成功 | - |
| 400001 | 無效的模型狀況 | 查無符合條件的資料 |
| 404001 | 未找到資料 | 請確認查詢條件是否正確 |
| 900000 | SQL執行例外狀況 | SQL執行例外狀況  |
| 901000 | 參數驗證失敗 | 請檢查必填欄位是否完整 |
| 999999 | 不明或未定義的錯誤 | 發生未預期錯誤，請聯繫系統管理員 |

---

## 變更紀錄
| 日期 | 版本 | 變更內容 | 負責人 |
| --- | --- | --- | --- |
| 2026/11/06 | 1.0 | 初版 | 李桂昇 |
| 2026/11/06 | 1.1 | 依更新後分析文件調整狀態3、4的有效日期查詢條件 | 李桂昇 |
