"""
zip_to_qr_video.py

把任意檔案(例如 .zip)編碼成一段 QR 碼影片,用手機拍下這段影片後,
再用這支程式解碼還原回原始檔案。

用法:
    編碼: python zip_to_qr_video.py encode <輸入檔> <輸出影片.mp4> [選項]
    解碼: python zip_to_qr_video.py decode <輸入影片> <輸出檔> [選項]

執行 python zip_to_qr_video.py -h 查看完整選項說明。
"""

import argparse
import base64
import glob
import hashlib
import os
import subprocess
import sys
import tempfile
import shutil


def get_ffmpeg_exe():
    """取得可用的 ffmpeg 執行檔路徑,第一次執行會自動下載(需要網路)。"""
    import imageio_ffmpeg
    print("檢查/下載 ffmpeg 中(第一次執行會需要下載,之後會直接重複使用)...")
    return imageio_ffmpeg.get_ffmpeg_exe()


def run_ffmpeg(ffmpeg_exe, args):
    cmd = [ffmpeg_exe] + args
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"ffmpeg 執行失敗 (exit code {result.returncode}):\n{result.stderr}")


def encode(input_path, output_path, chunk_size, fps, repeat, box_size):
    import qrcode
    from qrcode.constants import ERROR_CORRECT_M

    with open(input_path, "rb") as f:
        data = f.read()

    file_hash = hashlib.sha256(data).hexdigest()
    total = (len(data) + chunk_size - 1) // chunk_size
    print(f"檔案大小: {len(data)} bytes,分成 {total} 個區塊,SHA-256: {file_hash}")

    temp_dir = tempfile.mkdtemp(prefix="ziptoqr_")

    try:
        frame_index = 0
        for i in range(total):
            offset = i * chunk_size
            chunk = data[offset:offset + chunk_size]
            b64 = base64.b64encode(chunk).decode("ascii")

            # 每一格內容格式: 區塊編號|總區塊數|整檔SHA256|base64資料
            payload = f"{i}|{total}|{file_hash}|{b64}"

            qr = qrcode.QRCode(error_correction=ERROR_CORRECT_M, box_size=box_size, border=4)
            qr.add_data(payload)
            qr.make(fit=True)
            img = qr.make_image(fill_color="black", back_color="white")

            # 同一格重複寫入 repeat 次,增加手機拍攝時真正掃到這格的機率
            for _r in range(repeat):
                frame_path = os.path.join(temp_dir, f"frame_{frame_index:06d}.png")
                img.save(frame_path)
                frame_index += 1

            if i % 20 == 0 or i == total - 1:
                print(f"已產生 QR 碼影格 {i + 1}/{total}")

        print("正在用 ffmpeg 合成影片...")
        ffmpeg_exe = get_ffmpeg_exe()
        pattern = os.path.join(temp_dir, "frame_%06d.png")
        run_ffmpeg(ffmpeg_exe, [
            "-y",
            "-framerate", str(fps),
            "-i", pattern,
            "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2",
            "-c:v", "libx264",
            "-pix_fmt", "yuv420p",
            output_path,
        ])

        print(f"完成! 輸出影片: {output_path}")
        print(f"請記下這個雜湊值,解碼完成後可自行核對: {file_hash}")

    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


def decode(input_video_path, output_path, sample_fps):
    from PIL import Image
    from pyzbar.pyzbar import decode as zbar_decode

    temp_dir = tempfile.mkdtemp(prefix="ziptoqr_decode_")

    try:
        print("正在用 ffmpeg 從影片擷取畫面...")
        ffmpeg_exe = get_ffmpeg_exe()
        pattern = os.path.join(temp_dir, "frame_%06d.png")
        run_ffmpeg(ffmpeg_exe, [
            "-y",
            "-i", input_video_path,
            "-vf", f"fps={sample_fps}",
            pattern,
        ])

        frame_paths = sorted(glob.glob(os.path.join(temp_dir, "frame_*.png")))
        print(f"共擷取 {len(frame_paths)} 張畫面,開始解碼 QR 碼...")

        chunks = {}
        total = -1
        file_hash = None

        for frame_path in frame_paths:
            try:
                img = Image.open(frame_path)
                results = zbar_decode(img)
            except Exception:
                continue  # 這張畫面讀取失敗就跳過,靠其他張補上

            for result in results:
                if result.type != "QRCODE":
                    continue

                try:
                    text = result.data.decode("utf-8")
                except Exception:
                    continue

                parts = text.split("|", 3)
                if len(parts) != 4:
                    continue

                idx_str, total_str, hash_str, b64 = parts
                if not idx_str.isdigit() or not total_str.isdigit():
                    continue

                index = int(idx_str)
                frame_total = int(total_str)

                if total == -1:
                    total = frame_total
                    file_hash = hash_str
                    print(f"偵測到檔案共 {total} 個區塊,SHA-256: {file_hash}")
                elif frame_total != total or hash_str != file_hash:
                    continue  # 跟已知檔案資訊對不上,可能是誤判,跳過

                if index not in chunks:
                    try:
                        chunks[index] = base64.b64decode(b64)
                    except Exception:
                        pass  # base64 解不出來,當作這張沒掃到

        if total == -1:
            print("沒有偵測到任何有效的 QR 碼。請確認影片內容清楚,或試著提高 --sample-fps。", file=sys.stderr)
            return 1

        missing = [i for i in range(total) if i not in chunks]
        if missing:
            print(f"缺少 {len(missing)}/{total} 個區塊,無法完整還原。", file=sys.stderr)
            shown = missing[:50]
            more = " ..." if len(missing) > 50 else ""
            print("缺少的區塊編號: " + ", ".join(map(str, shown)) + more, file=sys.stderr)
            print("建議: 錄影時放慢播放速度(降低編碼端 --fps)或提高解碼端 --sample-fps 後重新拍攝。", file=sys.stderr)
            return 1

        file_data = b"".join(chunks[i] for i in range(total))
        actual_hash = hashlib.sha256(file_data).hexdigest()

        if actual_hash != file_hash:
            print("錯誤: 重組後的檔案雜湊值不符,資料可能已損毀。", file=sys.stderr)
            print(f"預期: {file_hash}", file=sys.stderr)
            print(f"實際: {actual_hash}", file=sys.stderr)
            return 1

        with open(output_path, "wb") as f:
            f.write(file_data)

        print(f"成功還原!輸出檔案: {output_path} ({len(file_data)} bytes)")
        print("雜湊值核對通過,檔案完整無誤。")
        return 0

    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


def main():
    parser = argparse.ArgumentParser(description="把檔案編碼成 QR 碼影片,或從影片解碼還原檔案")
    sub = parser.add_subparsers(dest="command", required=True)

    p_encode = sub.add_parser("encode", help="把檔案編碼成 QR 碼影片")
    p_encode.add_argument("input", help="輸入檔案路徑(例如 myfile.zip)")
    p_encode.add_argument("output", help="輸出影片路徑(例如 output.mp4)")
    p_encode.add_argument("--chunk-size", type=int, default=400, help="每格 QR 碼帶的原始資料 bytes 數 (預設 400)")
    p_encode.add_argument("--fps", type=int, default=2, help="影片播放速度,每秒幾格 (預設 2)")
    p_encode.add_argument("--repeat", type=int, default=2, help="每格重複播放幾次 (預設 2)")
    p_encode.add_argument("--qr-scale", type=int, default=10, help="每個 QR 模組的像素數 (預設 10)")

    p_decode = sub.add_parser("decode", help="從 QR 碼影片解碼還原檔案")
    p_decode.add_argument("input", help="輸入影片路徑")
    p_decode.add_argument("output", help="輸出檔案路徑(例如 output.zip)")
    p_decode.add_argument("--sample-fps", type=int, default=10, help="從影片取樣的幀率 (預設 10,建議大於編碼端 --fps)")

    args = parser.parse_args()

    try:
        if args.command == "encode":
            encode(args.input, args.output, args.chunk_size, args.fps, args.repeat, args.qr_scale)
            return 0
        elif args.command == "decode":
            return decode(args.input, args.output, args.sample_fps)
    except Exception as ex:
        print(f"錯誤: {ex}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
