"""
clean_zip.py

從一個 zip 檔裡篩選掉常見的 .NET(或其他語言)建置產物、快取資料夾,
只留下真正的原始碼與專案設定檔,輸出成一個新的、乾淨許多的 zip 檔。
也可以用來分析一個 zip 裡的內容組成,找出真正佔用空間的東西。

不會修改或刪除你原本的 zip 檔,只會產生一個新檔案。

用法:
    分析: python clean_zip.py analyze <zip 檔>
    清理: python clean_zip.py clean <輸入.zip> <輸出.zip> [選項]

清理選項:
    --list-only              只列出會排除什麼,不產生新檔案
    --exclude-dir NAME        額外排除的資料夾名稱,可重複使用
    --exclude-ext .ext        額外排除的副檔名,可重複使用(例如 --exclude-ext .png)
    --exclude-suffix .xxx     額外排除的檔名結尾樣式,可重複使用(例如 --exclude-suffix .min.js,
                              用來抓 bootstrap.min.js 這種雙重副檔名,不會誤殺一般 .js 檔)

預設已經會排除 .min.js / .min.css(通常是第三方壓縮函式庫,不是你自己的原始碼)
"""

import argparse
import os
import sys
import tarfile
import time
import zipfile
from io import BytesIO
from pathlib import PurePosixPath


DEFAULT_EXCLUDE_DIRS = {
    "bin", "obj",
    ".vs",
    ".git",
    "packages",
    ".nuget",
    "node_modules",
    "testresults",
    ".idea",
    "artifacts",
    "publish",
}

DEFAULT_EXCLUDE_EXTS = {
    ".dll", ".pdb", ".exe", ".cache", ".suo", ".user",
    ".ncb", ".sdf", ".log", ".vsidx", ".ipch",
}

# 檔名「結尾樣式」比對,用來抓 .min.js / .min.css 這種雙重副檔名的第三方壓縮檔
# 跟 exclude_exts 不同: exclude_exts 只看最後一個點之後的部分(.js),
# 這裡看的是完整結尾字串,才能精準只抓 xxx.min.js,不會誤殺 xxx.js
DEFAULT_EXCLUDE_NAME_SUFFIXES = {
    ".min.js", ".min.css",
}


def should_exclude(entry_path: str, exclude_dirs: set, exclude_exts: set, exclude_name_suffixes: set = frozenset()) -> bool:
    posix_path = PurePosixPath(entry_path)
    parts_lower = {p.lower() for p in posix_path.parts}

    if parts_lower & exclude_dirs:
        return True

    if posix_path.suffix.lower() in exclude_exts:
        return True

    name_lower = posix_path.name.lower()
    if any(name_lower.endswith(suf) for suf in exclude_name_suffixes):
        return True

    return False


def analyze_zip(zip_path, top_n=20):
    with zipfile.ZipFile(zip_path, "r") as z:
        infos = [i for i in z.infolist() if not i.is_dir()]

    total_size = sum(i.file_size for i in infos)
    print(f"檔案總數: {len(infos):,}, 總大小: {total_size:,} bytes ({total_size / 1024 / 1024:.2f} MB)\n")

    by_ext = {}
    for info in infos:
        ext = PurePosixPath(info.filename).suffix.lower() or "(無副檔名)"
        size, count = by_ext.get(ext, (0, 0))
        by_ext[ext] = (size + info.file_size, count + 1)

    print(f"依副檔名彙總(前 {top_n} 大):")
    print(f"{'副檔名':<16}{'檔案數':>8}{'總大小':>16}{'佔比':>8}")
    for ext, (size, count) in sorted(by_ext.items(), key=lambda kv: -kv[1][0])[:top_n]:
        pct = (size / total_size * 100) if total_size else 0
        print(f"{ext:<16}{count:>8}{size:>14,} B{pct:>7.1f}%")

    print(f"\n單一檔案最大的前 {top_n} 個:")
    for info in sorted(infos, key=lambda i: -i.file_size)[:top_n]:
        print(f"  {info.file_size:>12,} B  {info.filename}")


def clean_zip(input_path, output_path, extra_exclude_dirs, extra_exclude_exts, extra_exclude_suffixes, list_only):
    exclude_dirs = DEFAULT_EXCLUDE_DIRS | {d.lower() for d in extra_exclude_dirs}
    exclude_exts = DEFAULT_EXCLUDE_EXTS | {e.lower() for e in extra_exclude_exts}
    exclude_name_suffixes = DEFAULT_EXCLUDE_NAME_SUFFIXES | {s.lower() for s in extra_exclude_suffixes}

    kept = []
    skipped = []

    with zipfile.ZipFile(input_path, "r") as src:
        infos = src.infolist()

        for info in infos:
            if info.is_dir():
                continue
            if should_exclude(info.filename, exclude_dirs, exclude_exts, exclude_name_suffixes):
                skipped.append(info)
            else:
                kept.append(info)

        original_total = sum(i.file_size for i in infos if not i.is_dir())
        kept_total = sum(i.file_size for i in kept)
        skipped_total = sum(i.file_size for i in skipped)

        print(f"原始檔案數: {len([i for i in infos if not i.is_dir()])}, 總大小: {original_total:,} bytes")
        print(f"保留檔案數: {len(kept)}, 保留大小: {kept_total:,} bytes")
        print(f"排除檔案數: {len(skipped)}, 排除大小: {skipped_total:,} bytes")

        if skipped:
            print("\n被排除的檔案(最多顯示前 30 個,依大小排序):")
            for info in sorted(skipped, key=lambda i: -i.file_size)[:30]:
                print(f"  - {info.filename} ({info.file_size:,} bytes)")
            if len(skipped) > 30:
                print(f"  ... 還有 {len(skipped) - 30} 個")

        if list_only:
            print("\n(--list-only 模式,沒有產生新檔案)")
            return

        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as dst:
            for info in kept:
                data = src.read(info.filename)
                dst.writestr(info, data)

    print(f"\n完成! 輸出乾淨的 zip: {output_path}")
    if original_total > 0:
        reduction = (1 - kept_total / original_total) * 100
        print(f"大小從 {original_total:,} bytes 減少到 {kept_total:,} bytes(減少約 {reduction:.1f}%)")


def repack_to_tarxz(input_zip_path, output_tarxz_path):
    """把 zip 內容改用 tar.xz(整體 solid 壓縮)重新打包,比較看看是否比 zip 更小。
    zip 是逐檔獨立壓縮,tar.xz 是把所有檔案串成一條資料流一起壓縮,
    能抓到「不同檔案之間」的重複內容(zip 完全抓不到這種跨檔案重複)。"""
    with zipfile.ZipFile(input_zip_path, "r") as src:
        infos = [i for i in src.infolist() if not i.is_dir()]
        original_zip_size = os.path.getsize(input_zip_path)

        with tarfile.open(output_tarxz_path, "w:xz", preset=9) as tar:
            for info in infos:
                data = src.read(info.filename)
                tarinfo = tarfile.TarInfo(name=info.filename)
                tarinfo.size = len(data)
                # zip 的時間格式轉成 tar 需要的 unix timestamp
                try:
                    tarinfo.mtime = time.mktime((*info.date_time, 0, 0, -1))
                except Exception:
                    tarinfo.mtime = time.time()
                tar.addfile(tarinfo, BytesIO(data))

    new_size = os.path.getsize(output_tarxz_path)
    print(f"原始 zip 大小: {original_zip_size:,} bytes ({original_zip_size / 1024 / 1024:.2f} MB)")
    print(f"tar.xz 大小: {new_size:,} bytes ({new_size / 1024 / 1024:.2f} MB)")
    if original_zip_size > 0:
        diff_pct = (1 - new_size / original_zip_size) * 100
        if diff_pct > 0:
            print(f"tar.xz 比 zip 小 {diff_pct:.1f}%")
        else:
            print(f"tar.xz 反而比 zip 大 {-diff_pct:.1f}%(代表你的內容本身跨檔案重複性不高)")


def main():
    parser = argparse.ArgumentParser(description="分析或清理 zip 檔內容,協助只留下原始碼")
    sub = parser.add_subparsers(dest="command", required=True)

    p_analyze = sub.add_parser("analyze", help="分析 zip 內容組成(依副檔名、依檔案大小)")
    p_analyze.add_argument("zip", help="要分析的 zip 檔路徑")
    p_analyze.add_argument("--top", type=int, default=20, help="顯示前幾筆(預設 20)")

    p_clean = sub.add_parser("clean", help="清理 zip,排除建置產物,輸出新的 zip")
    p_clean.add_argument("input", help="輸入 zip 檔路徑")
    p_clean.add_argument("output", help="輸出 zip 檔路徑")
    p_clean.add_argument("--list-only", action="store_true", help="只列出會排除什麼,不實際產生新檔案")
    p_clean.add_argument("--exclude-dir", action="append", default=[], help="額外要排除的資料夾名稱,可重複使用")
    p_clean.add_argument("--exclude-ext", action="append", default=[], help="額外要排除的副檔名,可重複使用(例如 --exclude-ext .png)")
    p_clean.add_argument("--exclude-suffix", action="append", default=[], help="額外要排除的檔名結尾樣式,可重複使用(例如 --exclude-suffix .min.js)")

    p_repack = sub.add_parser("repack", help="把 zip 改用 tar.xz(solid壓縮)重新打包,比較是否更小")
    p_repack.add_argument("input", help="輸入 zip 檔路徑")
    p_repack.add_argument("output", help="輸出 tar.xz 檔路徑")

    args = parser.parse_args()

    try:
        if args.command == "analyze":
            analyze_zip(args.zip, args.top)
        elif args.command == "clean":
            clean_zip(args.input, args.output, args.exclude_dir, args.exclude_ext, args.exclude_suffix, args.list_only)
        elif args.command == "repack":
            repack_to_tarxz(args.input, args.output)
    except Exception as ex:
        print(f"錯誤: {ex}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
