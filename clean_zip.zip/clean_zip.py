"""
clean_zip.py

從一個 zip 檔裡篩選掉常見的 .NET(或其他語言)建置產物、快取資料夾,
只留下真正的原始碼與專案設定檔,輸出成一個新的、乾淨許多的 zip 檔。

不會修改或刪除你原本的 zip 檔,只會產生一個新檔案。

用法:
    python clean_zip.py <輸入.zip> <輸出.zip>
    python clean_zip.py <輸入.zip> <輸出.zip> --list-only     只列出會刪掉什麼,不產生新檔案
    python clean_zip.py <輸入.zip> <輸出.zip> --exclude-dir foo --exclude-dir bar   額外排除自訂資料夾名稱
"""

import argparse
import sys
import zipfile
from pathlib import PurePosixPath


# 預設要排除的資料夾名稱(不分大小寫,只要路徑中任何一層資料夾名稱符合就整個排除)
DEFAULT_EXCLUDE_DIRS = {
    "bin", "obj",              # .NET 編譯輸出與中繼檔
    ".vs",                     # Visual Studio 本機快取
    ".git",                    # git 版本歷史(通常很大,而且不算「程式碼本身」)
    "packages",                # 舊式 NuGet packages 資料夾
    ".nuget",                  # NuGet 快取
    "node_modules",            # 前端相依套件(若專案有混前端)
    "testresults",             # 測試報告
    ".idea",                   # JetBrains Rider 快取
    "artifacts",               # 常見發佈輸出資料夾
    "publish",                 # dotnet publish 輸出
}

# 預設要排除的副檔名(不分大小寫)
DEFAULT_EXCLUDE_EXTS = {
    ".dll", ".pdb", ".exe", ".cache", ".suo", ".user",
    ".ncb", ".sdf", ".log", ".vsidx", ".ipch",
}


def should_exclude(entry_path: str, exclude_dirs: set, exclude_exts: set) -> bool:
    posix_path = PurePosixPath(entry_path)
    parts_lower = {p.lower() for p in posix_path.parts}

    if parts_lower & exclude_dirs:
        return True

    if posix_path.suffix.lower() in exclude_exts:
        return True

    return False


def clean_zip(input_path, output_path, extra_exclude_dirs, list_only):
    exclude_dirs = DEFAULT_EXCLUDE_DIRS | {d.lower() for d in extra_exclude_dirs}
    exclude_exts = DEFAULT_EXCLUDE_EXTS

    kept = []
    skipped = []

    with zipfile.ZipFile(input_path, "r") as src:
        infos = src.infolist()

        for info in infos:
            if info.is_dir():
                continue
            if should_exclude(info.filename, exclude_dirs, exclude_exts):
                skipped.append(info)
            else:
                kept.append(info)

        original_total = sum(i.file_size for i in infos if not i.is_dir())
        kept_total = sum(i.file_size for i in kept)
        skipped_total = sum(i.file_size for i in skipped)

        print(f"原始檔案數: {len([i for i in infos if not i.is_dir()])}, 總大小: {original_total:,} bytes")
        print(f"保留檔案數: {len(kept)}, 保留大小: {kept_total:,} bytes")
        print(f"排除檔案數: {len(skipped)}, 排除大小: {skipped_total:,} bytes")

        if skipped:
            print("\n被排除的檔案(最多顯示前 30 個):")
            for info in skipped[:30]:
                print(f"  - {info.filename} ({info.file_size:,} bytes)")
            if len(skipped) > 30:
                print(f"  ... 還有 {len(skipped) - 30} 個")

        if list_only:
            print("\n(--list-only 模式,沒有產生新檔案)")
            return

        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as dst:
            for info in kept:
                data = src.read(info.filename)
                dst.writestr(info, data)

    print(f"\n完成! 輸出乾淨的 zip: {output_path}")
    if kept_total > 0:
        reduction = (1 - kept_total / original_total) * 100 if original_total else 0
        print(f"大小從 {original_total:,} bytes 減少到 {kept_total:,} bytes(減少約 {reduction:.1f}%)")


def main():
    parser = argparse.ArgumentParser(description="清理 zip 檔內的建置產物,只留下原始碼")
    parser.add_argument("input", help="輸入 zip 檔路徑")
    parser.add_argument("output", help="輸出 zip 檔路徑")
    parser.add_argument("--list-only", action="store_true", help="只列出會排除什麼,不實際產生新檔案")
    parser.add_argument("--exclude-dir", action="append", default=[], help="額外要排除的資料夾名稱,可重複使用")

    args = parser.parse_args()

    try:
        clean_zip(args.input, args.output, args.exclude_dir, args.list_only)
    except Exception as ex:
        print(f"錯誤: {ex}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
